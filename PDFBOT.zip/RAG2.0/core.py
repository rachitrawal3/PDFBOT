# core.py
import os
import tempfile
import psycopg
from functools import lru_cache

from langchain_groq import ChatGroq
from langchain_community.document_loaders import PyMuPDFLoader
from langchain_huggingface import HuggingFaceEmbeddings
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_qdrant import QdrantVectorStore
from langchain_postgres import PostgresChatMessageHistory
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain_core.runnables import RunnablePassthrough, RunnableParallel
from langchain_core.output_parsers import StrOutputParser
from langchain_core.documents import Document

from qdrant_client import QdrantClient
from qdrant_client.http.models import Filter, FieldCondition, MatchValue

# --- Configuration ---
GROQ_API_KEY = os.getenv("GROQ_API_KEY")
QDRANT_URL = os.getenv("QDRANT_URL")
POSTGRES_URL = os.getenv("POSTGRES_URL")
EMBEDDING_MODEL_NAME = os.getenv("EMBEDDING_MODEL_NAME")
QDRANT_COLLECTION_NAME = os.getenv("QDRANT_COLLECTION_NAME")
CHAT_TABLE_NAME = "chat_history"

# --- Component Initialization (using standard lru_cache for backend) ---
@lru_cache(maxsize=1)
def get_qdrant_client():
    """Initializes and returns a QdrantClient instance."""
    return QdrantClient(url=QDRANT_URL)

@lru_cache(maxsize=1)
def get_embeddings_model():
    """Loads and caches the HuggingFace Embeddings model."""
    return HuggingFaceEmbeddings(model_name=EMBEDDING_MODEL_NAME)

@lru_cache(maxsize=1)
def get_text_splitter():
    """Initializes and caches the RecursiveCharacterTextSplitter."""
    return RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=200)

@lru_cache(maxsize=1)
def get_llm():
    """Initializes and caches the Groq LLM."""
    return ChatGroq(groq_api_key=GROQ_API_KEY, model_name="gemma2-9b-it", temperature=0.3)

@lru_cache(maxsize=1)
def get_postgres_connection():
    """Establishes and caches the PostgreSQL connection."""
    try:
        conn = psycopg.connect(POSTGRES_URL)
        PostgresChatMessageHistory.create_tables(conn, CHAT_TABLE_NAME)
        return conn
    except Exception as e:
        raise ConnectionError(f"Could not connect to PostgreSQL database: {e}") from e

# --- Database & File Processing Functions ---
def get_chat_message_history(session_id: str, connection):
    """Retrieves a PostgresChatMessageHistory instance using a provided connection."""
    if not connection:
        raise ValueError("A valid database connection must be provided.")
    return PostgresChatMessageHistory(CHAT_TABLE_NAME, session_id, sync_connection=connection)

def process_and_index_pdf(uploaded_file, embeddings_model, text_splitter):
    """Loads, processes, and indexes a single uploaded PDF file into Qdrant."""
    try:
        with tempfile.NamedTemporaryFile(delete=False, suffix=".pdf") as tmp_file:
            content = uploaded_file.file.read()
            tmp_file.write(content)
            tmp_file_path = tmp_file.name

        loader = PyMuPDFLoader(tmp_file_path)
        documents = loader.load()
        chunks = text_splitter.split_documents(documents)

        for chunk in chunks:
            chunk.metadata.update({"file_name": uploaded_file.filename, "page": chunk.metadata.get("page", 0) + 1})

        QdrantVectorStore.from_documents(
            documents=chunks,
            embedding=embeddings_model,
            url=QDRANT_URL,
            collection_name=QDRANT_COLLECTION_NAME,
        )
        return True, f"Successfully indexed '{uploaded_file.filename}'."
    except Exception as e:
        return False, f"Error processing '{uploaded_file.filename}': {e}"
    finally:
        if 'tmp_file_path' in locals() and os.path.exists(tmp_file_path):
            os.remove(tmp_file_path)

def get_unique_document_names(qdrant_client: QdrantClient) -> list[str]:
    """Fetches unique document names from Qdrant metadata."""
    try:
        scroll_result, _ = qdrant_client.scroll(
            collection_name=QDRANT_COLLECTION_NAME, limit=1000, with_payload=["metadata.file_name"], with_vectors=False
        )
        unique_names = {point.payload['metadata']['file_name'] for point in scroll_result if point.payload}
        return sorted(list(unique_names))
    except Exception:
        return []

# --- RAG Chain Definition ---
def format_docs(docs: list[Document]) -> str:
    """Formats retrieved documents for inclusion in the prompt."""
    return "\n\n".join(
        f"Source: {doc.metadata.get('file_name', 'N/A')} (Page {doc.metadata.get('page', 'N/A')})\n"
        f"Content: {doc.page_content}" for doc in docs
    )

def get_rag_chain(llm, retriever, connection):
    """Constructs the RAG chain with the corrected prompt and logic."""
    system_prompt = (
        "You are an expert AI assistant. Your task is to answer questions based *only* on the provided context. "
        "For each fact, statement, or number you use, you must provide a clear citation to the source document and page number in the format `[Source: FileName (Page X)]`. "
        "Combine information from multiple sources if necessary, but cite each piece of information. "
        "If the provided context does not contain the answer, you must state: 'I cannot answer this question based on the provided documents.' "
        "Do not use any external knowledge."
    )
    
    human_prompt_template = "Based on the context below, please answer the question.\n\nCONTEXT:\n{context}\n\nQUESTION:\n{question}"

    qa_prompt = ChatPromptTemplate.from_messages([
        ("system", system_prompt),
        MessagesPlaceholder(variable_name="chat_history"),
        ("human", human_prompt_template),
    ])

    answer_generation_chain = (
        RunnablePassthrough.assign(
            context=lambda x: format_docs(x["context_docs"]),
            chat_history=lambda x: get_chat_message_history(x["session_id"], x["connection"]).messages
        )
        | qa_prompt
        | llm
        | StrOutputParser()
    )

    rag_chain = (
        RunnablePassthrough.assign(context_docs=lambda x: retriever.invoke(x["question"]))
        | RunnableParallel({"answer": answer_generation_chain, "context_docs": lambda x: x["context_docs"]})
    )
    return rag_chain