# frontend_app.py

import streamlit as st
import requests
import uuid

# --- Configuration ---
BACKEND_URL = "http://localhost:8000"


def initialize_application_state():
    """
    Calls the backend's /reset endpoint to clear the Qdrant collection.
    Uses a session_state flag to run only once per browser session.
    """
    if "app_initialized" not in st.session_state:
        try:
            # Display a temporary message to the user
            st.toast("Requesting a fresh session from the backend...", icon="🔄")
            # Make the API call to the new /reset endpoint
            response = requests.post(f"{BACKEND_URL}/reset")
            response.raise_for_status() # Raise an exception for bad status codes (4xx or 5xx)
            st.toast("Session is fresh and ready!", icon="✅")
        except requests.exceptions.RequestException as e:
            # If the backend is down or there's an error, inform the user but don't crash
            st.warning(f"Could not reset the backend state. Using existing documents. Details: {e}")
        
        # Set the flag to True so this block doesn't run again during this session
        st.session_state.app_initialized = True

# --- UI Layout ---
st.set_page_config(page_title="AlgorithmX RAG Assessment", layout="wide")

# --- Call the initialization function at the start of every script run ---
# The logic inside the function ensures it only acts once per session.
initialize_application_state()

# --- Session State Management ---
if "chat_session_id" not in st.session_state:
    st.session_state.chat_session_id = str(uuid.uuid4())
    st.session_state.messages = []

st.title("📄 AlgorithmX RAG Assessment")
st.markdown("An interactive RAG application. Each new session starts with a clean slate.")

# --- Helper Functions to Call Backend ---
def get_indexed_docs():
    """Fetches the list of currently indexed documents from the backend."""
    try:
        response = requests.get(f"{BACKEND_URL}/documents")
        response.raise_for_status()
        return response.json()
    except requests.exceptions.RequestException:
        # Fail gracefully if the backend is not reachable
        return []

# --- Sidebar ---
with st.sidebar:
    st.header("Upload & Settings")
    uploaded_files = st.file_uploader("Choose PDF files", type="pdf", accept_multiple_files=True)
    if uploaded_files and st.button("Process & Index PDFs"):
        for file in uploaded_files:
            with st.spinner(f"Uploading '{file.name}'..."):
                try:
                    files = {"file": (file.name, file, "application/pdf")}
                    # Set a long timeout for potentially large file uploads and processing
                    response = requests.post(f"{BACKEND_URL}/upload", files=files, timeout=600)
                    response.raise_for_status()
                    st.success(f"Successfully processed '{file.name}'", icon="✅")
                except requests.exceptions.RequestException as e:
                    error_detail = e.response.json().get('detail', str(e)) if e.response else str(e)
                    st.error(f"Failed to process '{file.name}'. Error: {error_detail}")
        st.rerun()

    st.subheader("Indexed Documents")
    doc_list = get_indexed_docs()
    if not doc_list: st.info("No documents indexed.")
    else:
        for doc_name in doc_list: st.markdown(f"- **{doc_name}**")

    with st.expander("⚙️ RAG Settings", expanded=True):
        st.session_state.top_k = st.slider("Chunks to retrieve (top_k)", 1, 10, 4)
        st.session_state.doc_filter = st.multiselect("Filter by Document(s)", ["All Documents"] + doc_list, default=["All Documents"])
        st.session_state.only_sources = st.checkbox("Only answer if sources are found")
    
    if st.button("Start New Chat Session"):
        st.session_state.chat_session_id = str(uuid.uuid4())
        st.session_state.messages = []
        st.rerun()

# --- Main Chat Interface ---
st.header("Chat with Your Documents")
for msg in st.session_state.messages:
    with st.chat_message(msg["role"]):
        st.markdown(msg["content"])
        if msg["role"] == "assistant" and "context_docs" in msg:
            with st.expander("Show Context"):
                for doc in msg["context_docs"]:
                    st.markdown(f"**Source:** {doc['metadata'].get('file_name', 'N/A')} (Page {doc['metadata'].get('page', 'N/A')})")
                    st.code(doc['page_content'])

if user_query := st.chat_input("Ask a question..."):
    st.session_state.messages.append({"role": "user", "content": user_query})
    with st.chat_message("user"): st.markdown(user_query)

    with st.chat_message("assistant"):
        with st.spinner("Thinking..."):
            try:
                payload = {
                    "session_id": st.session_state.chat_session_id,
                    "question": user_query,
                    "top_k": st.session_state.top_k,
                    "doc_filter": st.session_state.doc_filter,
                    "only_sources": st.session_state.only_sources,
                }
                response = requests.post(f"{BACKEND_URL}/chat", json=payload, timeout=120)
                response.raise_for_status()
                chat_response = response.json()

                st.markdown(chat_response["answer"])
                with st.expander("Show Context"):
                    for doc in chat_response["context_docs"]:
                        st.markdown(f"**Source:** {doc['metadata'].get('file_name', 'N/A')} (Page {doc['metadata'].get('page', 'N/A')})")
                        st.code(doc['page_content'])

                assistant_message = {"role": "assistant", "content": chat_response["answer"], "context_docs": chat_response["context_docs"]}
                st.session_state.messages.append(assistant_message)

            except requests.exceptions.RequestException as e:
                error_detail = e.response.json().get('detail', str(e)) if e.response else str(e)
                st.error(f"An error occurred: {error_detail}")