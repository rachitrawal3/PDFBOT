# backend_app.py

from fastapi import FastAPI, UploadFile, File, HTTPException
from pydantic import BaseModel
from typing import List, Dict, Any
from dotenv import load_dotenv

# Load environment variables at the very start
load_dotenv()

import core as core

app = FastAPI(
    title="AlgorithmX RAG Assessment Backend",
    description="API for processing PDFs and chatting with their content.",
)

# --- Pydantic Models for Request/Response Validation ---
class ChatRequest(BaseModel):
    session_id: str
    question: str
    top_k: int
    doc_filter: List[str]
    only_sources: bool

class ChatResponse(BaseModel):
    answer: str
    context_docs: List[Dict[str, Any]]

# --- API Endpoints ---
@app.post("/upload", status_code=201)
async def upload_pdf(file: UploadFile = File(...)):
    """Uploads a PDF, processes it, and indexes its content into Qdrant."""
    if file.content_type != "application/pdf":
        raise HTTPException(status_code=400, detail="Invalid file type. Only PDFs are accepted.")
    
    try:
        embeddings = core.get_embeddings_model()
        text_splitter = core.get_text_splitter()
        success, message = core.process_and_index_pdf(file, embeddings, text_splitter)
        if not success:
            raise HTTPException(status_code=500, detail=message)
        return {"filename": file.filename, "message": message}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"An unexpected error occurred: {e}")

@app.post("/chat", response_model=ChatResponse)
async def chat_with_documents(request: ChatRequest):
    """Handles a user's chat query, performs RAG, and returns the answer."""
    try:
        llm = core.get_llm()
        qdrant_client = core.get_qdrant_client()
        embeddings = core.get_embeddings_model()
        db_connection = core.get_postgres_connection()

        vectorstore = core.QdrantVectorStore(
            client=qdrant_client, collection_name=core.QDRANT_COLLECTION_NAME, embedding=embeddings
        )
        retriever = vectorstore.as_retriever(search_kwargs={"k": request.top_k})
        
        rag_chain = core.get_rag_chain(llm, retriever, db_connection)
        
        response = rag_chain.invoke({
            "question": request.question,
            "session_id": request.session_id,
            "connection": db_connection
        })

        history = core.get_chat_message_history(request.session_id, db_connection)
        history.add_user_message(request.question)
        history.add_ai_message(response["answer"])

        context_docs_serializable = [
            {"page_content": doc.page_content, "metadata": doc.metadata} for doc in response["context_docs"]
        ]
        return ChatResponse(answer=response["answer"], context_docs=context_docs_serializable)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"An error occurred during chat: {e}")
    
@app.post("/reset", status_code=200)
async def reset_vector_store():
    """
    Deletes and recreates the Qdrant collection to ensure a fresh start.
    """
    try:
        qdrant_client = core.get_qdrant_client()
        collection_name = core.QDRANT_COLLECTION_NAME
        
        # This will delete the collection if it exists.
        # It's safe to call even if the collection isn't there.
        qdrant_client.delete_collection(collection_name=collection_name)
        
        # Optional: Recreate it immediately to be ready.
        # This is good practice.
        qdrant_client.recreate_collection(
            collection_name=collection_name,
            vectors_config={"size": 384, "distance": "Cosine"} # Adjust size if your embedding model is different
        )
        
        return {"message": f"Collection '{collection_name}' has been reset successfully."}
    except Exception as e:
        # Even if it fails (e.g., collection didn't exist), we don't want to crash the app
        return {"message": f"Info: Could not reset collection (it may not have existed). Details: {e}"}

@app.get("/documents", response_model=List[str])
async def get_indexed_documents():
    """Returns a list of unique document names in the vector store."""
    try:
        qdrant_client = core.get_qdrant_client()
        return core.get_unique_document_names(qdrant_client)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to retrieve documents: {e}")